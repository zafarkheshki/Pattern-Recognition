
function [train,test] = LDA(train,test,num)

X1 = train{1}(:,num);
X2 = train{2}(:,num);
X3 = train{3}(:,num);
Mu1 = mean(X1);
Mu2 = mean(X2);
Mu3 = mean(X3);
Mu = (Mu1 + Mu2 + Mu3)/3;
Sw = cov(X1) + cov(X2) + cov(X3); % within class scatter matrix
m1 = Mu1-Mu;
m2 = Mu2-Mu;
m3 = Mu3-Mu;
[~,N1] = size(X1);
[~,N2] = size(X2);
[~,N3] = size(X3);
Sb1 = N1*(m1*transpose(m1));
Sb2 = N2*(m2*transpose(m2));
Sb3 = N3*(m3*transpose(m3));
Sb = Sb1 + Sb2 + Sb3; % between-class scatter matrix
SwSb = pinv(Sw)*Sb;
[v,d] = eig(SwSb,'vector'); % v - eigenvectors; d - eigenvalues 
[~,index] = sort(d); % sort according to eigenvalues
v = v(:,index); % use all eigenvectors for full reconstruction
% project data samplesalong he projection axes
new_X1 = (X1-Mu)*v;
new_X2 = (X2-Mu)*v;
new_X3 = (X3-Mu)*v;
train = {new_X1,new_X2,new_X3};
test = (v'*(test(:,num)'-Mu'))';

% DEBUG
% figure
% hold on
% scatter(1:numel(X1(:,1)),X1(:,1))
% scatter(1:numel(X2(:,1)),X2(:,1))
% scatter(1:numel(X3(:,1)),X3(:,1))
% hold off
% 
% figure
% scatter3(new_X1(:,1),new_X1(:,2),new_X1(:,3))
% hold on
% scatter3(new_X2(:,1),new_X2(:,2),new_X2(:,3))
% scatter3(new_X3(:,1),new_X3(:,2),new_X3(:,3))
% hold off

end
