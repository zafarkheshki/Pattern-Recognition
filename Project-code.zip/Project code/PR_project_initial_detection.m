function BW = PR_project_initial_detection(img)
  img_size = cellfun(@(x) size(x),img,'UniformOutput',false);  
  BW = cell(size(img));
parfor k = 1:length(img) 
  area = zeros(200,1);
  light_pix = zeros(200,1);
  dev = zeros(200,1);
  solidity = zeros(200,1);
  BW{k} = false(img_size{k});
  for i = [0.67, 0.67, 0.70, 0.70, 0.75, 0.75, 0.80, 0.80, 0.85, 0.85; ...
           5,    25,   5,    25,   5,    25,   5,    25    ,5,   25]
    img_temp = img{k};
    %DEBUG: figure; imshow(img_temp)
    temp_bright = false(img_size{k});
    temp_bright(img_temp>i(1)) = 1;
    temp_bright = bwareafilt(temp_bright,[1000,inf]);
    stats = regionprops(temp_bright,'Area','Solidity','PixelIdxList');
    temp_bright = false(size(img_temp));
    inds = [stats.Solidity]<0.8;
    inds2 = [stats.Area]>3000;
    temp_bright(vertcat(stats(or(inds,inds2)).PixelIdxList)) = 1;
    temp_bright = imerode(imdilate(temp_bright,strel('disk',i(2),8)),strel('disk',i(2),8));
    temp_bright = bwpropfilt(temp_bright,'EulerNumber',[-inf,0]);
    %DEBUG: figure; imshow(labeloverlay(img{k},temp_bright)) 
    background = bwareafilt(~temp_bright,1,4);
    BW{k}(~or(temp_bright,background)) = 1;
  end
  BW{k}(img{k}<0.65) = 1;
  BW{k} = bwareafilt(BW{k},[500,10000]);
  BW{k} = imclearborder(BW{k});
  stats = regionprops(BW{k},'PixelIdxList','Area','Solidity');
  for i = 1:length(stats)
    area(i) = stats(i).Area;
    light_pix(i) = (sum(img{k}(stats(i).PixelIdxList)>0.90,'all') ...
                    /area(i));     
    dev(i) = std(img{k}(stats(i).PixelIdxList));
    solidity(i) = stats(i).Solidity;
  end
  area = area(area~=0);
  light_pix = light_pix(1:length(area));
  dev = dev(1:length(area));
  solidity = solidity(area~=0);
  BW{k}(vertcat(stats(and(area<2200,light_pix>0.005) | dev<0.05 | solidity<0.6).PixelIdxList)) = 0; 
  
end
  
end  