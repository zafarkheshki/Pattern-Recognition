
%% Extracting cells from images
out = cell(3,1);
for i = 1:3
  img = PR_project_import(i);
  out{i} = PR_project_detection(img);
end

masks = {out{1}{1},out{2}{1},out{3}{1}};
imgs = {out{1}{2},out{2}{2},out{3}{2}};

num_cells = [length(masks{1}),length(masks{2}),length(masks{3})];

%% Preparing features
area = cell(3,1);
eccentricity = cell(3,1);
circularity = cell(3,1);
avg = cell(3,1);
dev = cell(3,1);

for k = 1:3
  area{k} = zeros(length(masks{k}),1);
  eccentricity{k} = zeros(length(masks{k}),1);
  circularity{k} = zeros(length(masks{k}),1);
  avg{k} = zeros(length(masks{k}),1);
  dev{k} = zeros(length(masks{k}),1);
  for i = 1:length(masks{k})
    stats = regionprops(masks{k}{i}{1},'Area','Perimeter','Eccentricity','PixelIdxList');
    area{k}(i) = stats.Area;
    eccentricity{k}(i) = stats.Eccentricity;
    circularity{k}(i) = (4*(pi*[stats.Area]))/([stats.Perimeter]^2 );
    avg{k}(i) = mean2(imgs{k}{i}(stats.PixelIdxList));
    dev{k}(i) = std(imgs{k}{i}(stats.PixelIdxList));
  end
end

% Normalising features
norm_data = normalize([[area{1};area{2};area{3}], ...
                       [eccentricity{1};eccentricity{2};eccentricity{3}], ...
                       [circularity{1};circularity{2};circularity{3}], ...
                       [avg{1};avg{2};avg{3}], ...
                       [dev{1};dev{2};dev{3}]],'range');

area = {norm_data(1:num_cells(1),1),norm_data(num_cells(1)+1:sum(num_cells(1:2)),1), ...
        norm_data(sum(num_cells(1:2))+1:end,1)};                     
eccentricity = {norm_data(1:num_cells(1),2),norm_data(num_cells(1)+1:sum(num_cells(1:2)),2), ...
                norm_data(sum(num_cells(1:2))+1:end,2)}; 
circularity = {norm_data(1:num_cells(1),3),norm_data(num_cells(1)+1:sum(num_cells(1:2)),3), ...
               norm_data(sum(num_cells(1:2))+1:end,3)}; 
avg = {norm_data(1:num_cells(1),4),norm_data(num_cells(1)+1:sum(num_cells(1:2)),4), ...
               norm_data(sum(num_cells(1:2))+1:end,4)}; 
dev = {norm_data(1:num_cells(1),5),norm_data(num_cells(1)+1:sum(num_cells(1:2)),5), ...
               norm_data(sum(num_cells(1:2))+1:end,5)}; 

%% Dividing data into train and test set 
perc = 0.7;
num_p = [(round(num_cells(1)*perc)),(round(num_cells(2)*perc)),(round(num_cells(3)*perc))];

train = {[area{1}(1:num_p(1)),eccentricity{1}(1:num_p(1)),circularity{1}(1:num_p(1))], ...
         [area{2}(1:num_p(2)),eccentricity{2}(1:num_p(2)),circularity{2}(1:num_p(2))], ...
         [area{3}(1:num_p(3)),eccentricity{3}(1:num_p(3)),circularity{3}(1:num_p(3))]};

test = [[area{1}(num_p(1)+1:end),eccentricity{1}(num_p(1)+1:end),circularity{1}(num_p(1)+1:end)]; ...
        [area{2}(num_p(2)+1:end),eccentricity{2}(num_p(2)+1:end),circularity{2}(num_p(2)+1:end)]; ...
        [area{3}(num_p(3)+1:end),eccentricity{3}(num_p(3)+1:end),circularity{3}(num_p(3)+1:end)]];

truth_vec = categorical([ones(1,(num_cells(1)-num_p(1))),2*ones(1,(num_cells(2)-num_p(2))), ...
                         3*ones(1,(num_cells(3)-num_p(3)))]);

%% Using the classifier                   
res_minDC = minDistClassifier(train,test,1:3);              
             
%% 10 fold cross validation

labels = [ones(num_cells(1),1);2*ones(num_cells(2),1);3*ones(num_cells(3),1)];
n = 10; % n fold cross validation
rng(k)
inds = 1:sum(num_cells);
inds = inds(randperm(length(inds)));
groups = zeros(n,floor(sum(num_cells)/n));
inds2 = 1:n:10*floor(sum(num_cells)/n);
for i = 1:floor(sum(num_cells)/n)
  groups(1:n,i) = inds(inds2(i):inds2(i)+(n-1));
end
class_mDC = zeros(10,size(groups,2));
class_mDC_LDA = zeros(10,size(groups,2));
class_mDC_PCA = zeros(10,size(groups,2));
test_labels = zeros(10,size(groups,2));
for i = 1:size(groups,2)

  train = norm_data(setdiff(inds,groups(:,i),'stable'),:);
  train_labels = labels(setdiff(inds,groups(:,i),'stable'),:);
  train = {train(train_labels==1,:),train(train_labels==2,:),train(train_labels==3,:)};
  test = norm_data(groups(:,i),:);
  test_labels(:,i) = labels(groups(:,i),:);

  % Minimum distance classifier using euclidian distance
  class_mDC(:,i) = minDistClassifier(train,test,1:3);

  % Minimum distance classifier using euclidian distance + PCA
  [train_PCA,test_PCA] = PCA(train,test,1:5);
  class_mDC_PCA(:,i) = minDistClassifier(train_PCA,test_PCA,1:3);
  
  % Minimum distance classifier using euclidian distance + LDA
  [train_LDA,test_LDA] = LDA(train,test,1:5);
  class_mDC_LDA(:,i) = minDistClassifier(train_LDA,test_LDA,1:3);
  
end

accuracy = mean(sum(class_mDC==test_labels,1)/n)*100;
accuracy_PCA = mean(sum(class_mDC_PCA==test_labels,1)/n)*100;
accuracy_LDA = mean(sum(class_mDC_LDA==test_labels,1)/n)*100;
stderr = std(sum(class_mDC==test_labels,1)/n)/sqrt(size(groups,2))*100;
stderr_PCA = std(sum(class_mDC_PCA==test_labels,1)/n)/sqrt(size(groups,2))*100;
stderr_LDA = std(sum(class_mDC_LDA==test_labels,1)/n)/sqrt(size(groups,2))*100;
accuracy_per_species = [mean(sum((class_mDC==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                        mean(sum((class_mDC==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                        mean(sum((class_mDC==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]*100;
accuracy_per_species_PCA = [mean(sum((class_mDC_PCA==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                            mean(sum((class_mDC_PCA==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                            mean(sum((class_mDC_PCA==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]*100;
accuracy_per_species_LDA = [mean(sum((class_mDC_LDA==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                            mean(sum((class_mDC_LDA==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                            mean(sum((class_mDC_LDA==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]*100;
stderr_per_species = [std(sum((class_mDC==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                      std(sum((class_mDC==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                      std(sum((class_mDC==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]/ ...
                      sqrt(sum(sum(test_labels==1)>0))*100;
stderr_per_species_PCA = [std(sum((class_mDC_PCA==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                          std(sum((class_mDC_PCA==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                          std(sum((class_mDC_PCA==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]/ ...
                          sqrt(sum(sum(test_labels==2)>0))*100;
stderr_per_species_LDA = [std(sum((class_mDC_LDA==1) & (test_labels==1),1)./sum(test_labels==1),'omitnan'), ...
                          std(sum((class_mDC_LDA==2) & (test_labels==2),1)./sum(test_labels==2),'omitnan'), ...
                          std(sum((class_mDC_LDA==3) & (test_labels==3),1)./sum(test_labels==3),'omitnan')]/ ...
                          sqrt(sum(sum(test_labels==3)>0))*100;
                    
                          
%% Preparing data for visualisation

imgs_train = {imgs{1}(1:num_p(1)),imgs{2}(1:num_p(2)),imgs{3}(1:num_p(3))};
masks_train = {masks{1}(1:num_p(1)),masks{2}(1:num_p(2)),masks{3}(1:num_p(3))};
for i = 1:3
  for j = 1:length(masks_train{i})
    if length(masks_train{i}{j})>1
      masks_train{i}{j} = bwmorph(or(masks_train{i}{j}{1},masks_train{i}{j}{2}),'bridge');
    else
      masks_train{i}{j} = masks_train{i}{j}{1};
    end
  end
end

imgs_test = {imgs{1}(num_p(1)+1:end),imgs{2}(num_p(2)+1:end),imgs{3}(num_p(3)+1:end)};
masks_test = {masks{1}(num_p(1)+1:end),masks{2}(num_p(2)+1:end),masks{3}(num_p(3)+1:end)};
for i = 1:3
  for j = 1:length(masks_test{i})
    if length(masks_test{i}{j})>1
      masks_test{i}{j} = bwmorph(or(masks_test{i}{j}{1},masks_test{i}{j}{2}),'bridge');
    else
      masks_test{i}{j} = masks_test{i}{j}{1};
    end
  end
end


%% Visualisation

% Visualising features
features = {area,eccentricity,circularity,avg,dev};
titles = ["Area","Eccentricity","Circularity","Mean","Standard deviation"];
% One dimensional features
figure
for i = 1:3
  subplot(2,3,i)
  hold on
  scatter(1:length(features{i}{1}(1:100)),features{i}{1}(1:100));
  scatter(1:length(features{i}{2}(1:100)),features{i}{2}(1:100));
  scatter(1:length(features{i}{3}(1:100)),features{i}{3}(1:100));
  title(titles(i))
  xlabel("Samples")
  ylabel("Normalised value")
  hold off
end
for i = 4:5
  subplot(2,2,i-1)
  hold on
  scatter(1:length(features{i}{1}(1:100)),features{i}{1}(1:100));
  scatter(1:length(features{i}{2}(1:100)),features{i}{2}(1:100));
  scatter(1:length(features{i}{3}(1:100)),features{i}{3}(1:100));
  title(titles(i))
  xlabel("Samples")
  ylabel("Normalised value")
  hold off
end

% Composite 3 dimensional feature
figure
for i = 1:3
  scatter3(features{1}{i}(1:50),features{2}{i}(1:50),features{3}{i}(1:50))
  hold on
end
xlabel("Normalised Area")
ylabel("Normalised Eccentricity")
zlabel("Normalised Circularity")

xticks(0:0.2:1)
yticks(0:0.2:1)
xticks(0:0.2:1)

% Ploting confusion matrices
figure
plotconfusion(truth_vec,categorical(res_minDC)); 

% Plotting the result of 10-fold cross validation per method per species
figure
c = ["Manual","PCA","LDA"];
accuracies = [[accuracy_per_species,accuracy];[accuracy_per_species_PCA,accuracy_PCA]; ...
              [accuracy_per_species_LDA,accuracy_LDA]];
stderrs = [[stderr_per_species,stderr];[stderr_per_species_PCA,stderr_PCA]; ...
           [stderr_per_species_LDA,stderr_LDA]]/2;
b = bar(1:3,accuracies);
ylabel("Percent accuracy")
hold on
ngroups = 3;
nbars = 4;
groupwidth = min(0.8, nbars/(nbars + 1.5));
for i = 1:nbars
    x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    er = errorbar(x, accuracies(:,i), stderrs(:,i));
    er.Color = [0 0 0];                            
    er.LineStyle = 'none';  
end
set(gca, 'XTickLabel', c);
hold off
legend({"S. cerevisiae","R. toruloides","L.starkeyi","Total"},'Location','bestoutside')

% Simulating real time classification

num = [length(imgs_test{1}),length(imgs_test{2}),length(imgs_test{3})];
labels_predicted = {res_minDC(1:num(1)), ...
                    res_minDC(num(1)+1:sum(num(1:2))), ...
                    res_minDC(sum(num(1:2))+1:sum(num))};
labels = {double(truth_vec(1:num(1))), ...
          double(truth_vec(num(1)+1:sum(num(1:2)))), ...
          double(truth_vec(sum(num(1:2))+1:sum(num)))};

PR_project_visualisation(imgs_test,masks_test, ...
                         [length(imgs_test{1}),length(imgs_test{2}),length(imgs_test{3})], ...
                         labels_predicted, labels);
                       
% blue - S. cerevisiae
% red - R. toruloides
% yellow   - L.�starkeyi
