function img = PR_project_import(num)

primary_dir = 'Examples';
species = ["cer","tor","sta"];
filenames = {string(1:11),string(1:10),string(1:9)};
img = cell(1,double(filenames{num}(end)));

parfor i = 1:str2double(filenames{num}(end))
  
  filename = char(filenames{num}(i));
  img_original = imread(strcat(primary_dir,'/',species(num),'/',filename,'.jpg')); % uploading the image
   
  % Converting to gray scale
  img{i} = rgb2gray(im2double(img_original));
  
  % Segmenting the eyepiece
  img_temp = img{i};
  img_temp(img_temp<0.25) = 0;
  img_temp(img_temp>=0.25) = 1;
  eyepiece = imopen(~bwareafilt(~bwareafilt(~img_temp,[20000,inf]),1),ones(10));
  
  % Removing the eyepiece              
  img{i}(eyepiece) = 0; 
  
  % Cropping the image
  [row,col] = find(img{i}~=0);
  row_min = min(row);
  row_max = max(row);
  col_min = min(col);
  col_max = max(col);
  img{i} = img{i}(row_min:row_max,col_min:col_max);
  
end

end