
function ind = minDistClassifier(train,test,inds)

  Mu1 = mean(train{1}(:,inds),1);
  Mu2 = mean(train{2}(:,inds),1);
  Mu3 = mean(train{3}(:,inds),1);
  ind = zeros(1,size(test,1));
  for i = 1:size(test,1)
    [~,ind(i)] = min([pdist2(test(i,inds),Mu1,'euclidean'); ... 
                      pdist2(test(i,inds),Mu2,'euclidean'); ...
                      pdist2(test(i,inds),Mu3,'euclidean')]);
  end
  
end