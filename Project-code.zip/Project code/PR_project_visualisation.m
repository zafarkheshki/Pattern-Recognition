function Image = PR_project_visualisation(imgs,masks,nums,labels_predicted,labels)
% Putting extracted cells on the final image 

% Initializing parameters
run_cnt = 0;
numOfobjects = sum(nums);
background = 0.85;
dif = 0.01;
circleInsideValue = background;
circleOutsideValue = 0.1;
imageWidth = 3000;
imageHeight =  3000;
[Image,circleRadius,Mask] = initImage();
for k = 1:length(imgs)
  for i = 1:nums(k)
    done = 0;
    while ~done

    img_size = size(imgs{k}{i});
    % Getting a random row, column location
    y1 = randi(imageHeight, 1);
    x1 = randi(imageWidth, 1);
    y2 = y1 + img_size(1) - 1;
    x2 = x1 + img_size(2) - 1;
    
    run_cnt = run_cnt+1;
    if run_cnt>(numOfobjects*10)
      imageWidth = imageWidth + 100;
      imageHeight = imageHeight +100;
      [Image,circleRadius,Mask] = initImage();
    end
      
    % See if any of those corners are outside the circle.  Skip if so
    if sqrt((x1 - imageWidth/2)^2 + (y1 - imageHeight/2)^2) > circleRadius
      continue;
    end
    if sqrt((x1 - imageWidth/2)^2 + (y2 - imageHeight/2)^2) > circleRadius
      continue;
    end
    if sqrt((x2 - imageWidth/2)^2 + (y1 - imageHeight/2)^2) > circleRadius
      continue;
    end
    if sqrt((x2 - imageWidth/2)^2 + (y2 - imageHeight/2)^2) > circleRadius
      continue;
    end

    % Making sure no overlap between objects is present

    if ~all(Image(y1:y2, x1) == circleInsideValue)
      continue;
    end
    if ~all(Image(y1, x1:x2) == circleInsideValue)
      continue;
    end
    if ~all(Image(y1:y2, x2) == circleInsideValue)
      continue;
    end
    if ~all(Image(y2, x1:x2) == circleInsideValue)
      continue;
    end

    Image(y1:y2, x1:x2) = imgs{k}{i};
    if iscell(labels)
      Mask(y1:y2, x1:x2) = masks{k}{i}*labels_predicted{k}(i);
      stats = regionprops(masks{k}{i},'Perimeter','Area');
      num_pix = round(stats.Area/stats.Perimeter*1.5);
      temp = xor(masks{k}{i},imerode(masks{k}{i},ones(num_pix)))*labels{k}(i);
      temp_log = xor(masks{k}{i},imerode(masks{k}{i},ones(num_pix)));
      temp_mask = Mask(y1:y2, x1:x2);
      temp_mask(temp_log) = temp(temp_log);
      Mask(y1:y2, x1:x2) = temp_mask;
    end
    done = 1;
    end
  end
end
Image(Image==background) = background + rand(1,sum(Image==background,'all'))*dif;
figure
if iscell(labels)
  Image = labeloverlay(Image,Mask,'Colormap',[0,0,1; 1,0,0; 1,1,0], ...
                                 'Transparency',0.5);
  Image = imgaussfilt(Image,0.51);
  imshow(Image)
else
  imshow(Image);
end
title('Simulation')

function [Image,circleRadius,Mask] = initImage()
circleRadius = round(imageWidth/2.05,-1);    % circle radius
Mask = zeros(imageHeight,imageWidth);
Image = circleOutsideValue*ones(imageHeight, imageWidth);
[x, y] = meshgrid(1:imageWidth, 1:imageHeight);
Image((x - imageWidth/2).^2 + (y - imageHeight/2).^2 <= circleRadius.^2) = circleInsideValue;
Image = imgaussfilt(Image,2);
Image((x - imageWidth/2).^2 + (y - imageHeight/2).^2 <= (circleRadius*0.98).^2) = circleInsideValue;
end

end