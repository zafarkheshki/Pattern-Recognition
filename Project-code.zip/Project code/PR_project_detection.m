function out = PR_project_detection(img)
warning('off','all')
img_size = cellfun(@(x) size(x),img,'UniformOutput',false);  
offset = 80;
BW = PR_project_initial_detection(img);
masks = cell(length(img),1);
imgs = cell(length(img),1);
parfor k = 1:length(img) 
  
  %DEBUG: figure; imshow(labeloverlay(img{k}, BW{k}))
  objects_BW = regionprops(BW{k}, 'PixelIdxList','PixelList');
  imgs{k} = cell(length(objects_BW),1);
  masks{k} = cell(length(objects_BW),1); 
 
  for l = 1:length(objects_BW)
    %% Segmenting cells
    row = [min(objects_BW(l).PixelList(:,2)),max(objects_BW(l).PixelList(:,2))];
    col = [min(objects_BW(l).PixelList(:,1)),max(objects_BW(l).PixelList(:,1))];
    if row(1)-offset<1
      row(1) = 1;
    else
      row(1) = row(1)-offset;
    end
    if col(1)-offset<1
      col(1) = 1;
    else
      col(1) = col(1)-offset;
    end
    if row(2)+offset>img_size{k}(1)
      row(2) = img_size{k}(1);
    else
      row(2) = row(2)+offset;
    end
    if col(2)+offset>img_size{k}(2)
      col(2) = img_size{k}(2);
    else
      col(2) = col(2)+offset;
    end
    
    mask_temp = false(img_size{k});
    mask_temp(objects_BW(l).PixelIdxList) = 1;
    mask_temp = mask_temp(row(1):row(2),col(1):col(2));
    img_temp = img{k}(row(1):row(2),col(1):col(2));

    %DEBUG: imshow(labeloverlay(img_temp,mask_temp)) 
    
    start = (round(mode(img_temp(img_temp~=0),'all'),2) - 0.1)*100;
    mask_mat = repmat(mask_temp,1,1,numel(start:2:90)*10);
    solidity = zeros(1,numel(start:2:90)*10);
    cnt = 1;
    for i = start:2:90
      br = 0;
      prc = prctile(img_temp,i,'all');    
      temp2 = false(size(img_temp));
      temp2(img_temp<prc) = 1;
      temp2 = bwareafilt(temp2,[500,inf]);
      obj2 = regionprops(temp2,'PixelIdxList');
      
      for b = 1 : length(obj2)
        temp2 = false(size(img_temp));                 % Collect objects to be
        temp2(obj2(b).PixelIdxList) = 1;               % considered for adding 
        temp3 = imclearborder(temp2);                  % to the mask
        temp4 = temp2;
        temp4(temp3) = 0;
        temp4 = bwareafilt(temp4,[500,inf]);
        no_border = temp2;
        no_border(temp4) = 0;
        no_border = bwareafilt(no_border, [50,inf]);
        
        if sum((no_border + mask_mat(:,:,cnt))==2,'all')
          difs = no_border;
          difs(mask_mat(:,:,cnt))=0;
          
          if sum(difs,'all')/(sum(mask_mat(:,:,end),'all'))<2.5
            obj_temp_temp = mask_mat(:,:,cnt);
            obj_temp_temp(no_border) = 1;
            mask_mat(:,:,cnt) = obj_temp_temp;
            stats_temp = regionprops(mask_mat(:,:,cnt),'Solidity');
            mask_mat(:,:,cnt) = imfill(mask_mat(:,:,cnt),'holes');
            solidity(:,cnt) = stats_temp.Solidity;
            cnt = cnt + 1;
          else
            br = 1;
            break
          end
        end
      end
      if br==1
        break
      end
    end
    mask_mat = mask_mat(:,:,1:cnt);
    solidity = solidity(:,1:cnt);
    if max(solidity)>0.90
      [~,ind] = max(solidity);
    else
      ind = numel(solidity);
    end
    solidity = solidity(ind);
    mask_mat = mask_mat(:,:,ind);
    
    mask_mat = imgaussfilt(double(mask_mat),2);
    mask_mat(mask_mat>0.5) = 1;
    mask_mat(mask_mat<=0.5) = 0;
    mask_mat = logical(mask_mat);
    mask_mat = bwmorph(mask_mat,'bridge');
    mask_mat = bwareafilt(mask_mat,1);
    %DEBUG: figure; imshow(labeloverlay(img_temp,mask_mat(:,:,end))) 
    line = 0;
    
    if solidity<0.98
  %% Further processing
    
    
    %% Find cell and bud

    D = mask_mat;
    D = bwdist(~D);
    D = -D;
    D(~mask_mat) = inf;
    L = watershed(D);
    L(~mask_mat) = 0;
    num_obj = max(max(L));
    cells = {false(size(img_temp)),false(size(img_temp))};
    %DEBUG: figure; imshow(L,[],'InitialMagnification','fit')
    
    if num_obj>1 && solidity<0.95
      comb = combnk(1:max(max(L)),2)';
      stats = regionprops(L,'Area','Perimeter','PixelIdxList');
      remove = zeros(2,numel(comb(1,:)));
      cnt = 1;
      for i = comb
        temp = L;
        temp(and(L~=i(1),L~=i(2))) = 0;
        temp = bwmorph(temp,'bridge');
        CC = bwconncomp(temp);
        if CC.NumObjects==1
          stats = [stats;regionprops(temp,'Area','Perimeter','PixelIdxList')];
        else
          remove(:,cnt) = i;
          cnt = cnt + 1;
        end
      end
      remove = remove(:,1:cnt);
      
      result = (4*(pi*[stats.Area]))./([stats.Perimeter] .^2 );
      result([stats.Area]/max([stats.Area])<0.15) = 0;
      result(result>1) = 1;
      [~,inds] = sort(result,'descend');
      nums = [repmat(1:num_obj,2,1),comb];
      if ~isempty(remove)
        nums = setdiff(nums',remove','rows','stable')';
      end
      nums = nums(:,inds);
      other_nums = unique(nums(:,2:end));
      othee_nums = setdiff(other_nums,nums(:,1));
      temp = {nums(:,1),othee_nums};
      area = zeros(1,2);
      for i = 1:2
        cells{i}(vertcat(stats(unique(temp{i})).PixelIdxList)) = 1;
        cells{i} = bwmorph(cells{i},'Bridge');
        CC = bwconncomp(cells{i});
        if CC.NumObjects~=1
          cells{i}(vertcat(CC.PixelIdxList{2:end})) = 0;
        end
        area(i) = sum([stats(unique(temp{i})).Area]);
      end
      [~,inds] = sort(area,'descend');
      cells = cells(inds);
      line = bwareafilt(xor(mask_mat,or(cells{1},cells{2})),1);
      for i = 1:length(cells)  
        stats = regionprops(cells{i},'Area','Perimeter');
        circularity = (4*(pi*[stats.Area]))/([stats.Perimeter] ^2 );
        if circularity<0.5
          cells = {mask_mat};
          line = 0;
          break
        end
      end
    else  
      cells{1} = mask_mat;
    end  

    if length(cells)~=1
      CC = bwconncomp(cells{2});
      if CC.NumObjects~=1
        cells = cells(1);
      end
    end
      
    if length(cells)~=1
      stats = regionprops(cells{2},'Area','Perimeter','MajorAxisLength','MinorAxisLength');
      temp = or(cells{1},cells{2});
      temp = bwmorph(temp,'Bridge');
      temp = xor(temp, or(cells{1},cells{2}));
      temp = sum(temp,'all');
      circularity = (4*(pi*[stats.Area]))/([stats.Perimeter] ^2 );
      if temp/stats.MajorAxisLength>0.5 || (circularity<0.9 || stats.Area>3000)
        cells = {bwmorph(or(cells{1},cells{2}),'Bridge')};
        line = 0;
      end
    end
    
    CC = bwconncomp(cells{1});
    if CC.NumObjects~=1 && length(cells)~=1
      temp = bwareafilt(cells{1},1,'smallest');
      cells{1}(temp) = 0;
      cells{2}(temp) = 1;
      cells{2}  = bwmorph(cells{2},'Bridge');
    end
    
    else
      cells = {mask_mat};
      line = 0;
    end  
  
  %% Smoothen
    for i = 1:length(cells)
      cells{i} = imgaussfilt(double(cells{i}),2);
      cells{i}(cells{i}>0.5) = 1;
      cells{i}(cells{i}<=0.5) = 0;
      cells{i} = logical(cells{i});
    end
 %% Separate cell and bud
    for i = 1:length(cells)
      if size(line)==size(cells{1})
        cells{i}(line) = 0;
      end
      cells{i} = bwareafilt(cells{i},1);
    end
    
 %% Filtering and saving for output
    if length(cells)>1
      cells_temp = imclose(or(cells{1},cells{2}),ones(3));
      CC = bwconncomp(cells_temp);
      if CC.NumObjects~=1
        cells_temp(vertcat(CC.PixelIdxList{2:end})) = 0;
      end
    else
      cells_temp = cells{1};
    end
    
    stats = regionprops(cells_temp,'Centroid');
    centroid = round(stats.Centroid);
    mask_ray = false(size(cells_temp));
    mask_ray_temp = false(size(cells_temp));
    [~,ind] = max([numel(mask_ray(centroid(2),:)),numel(mask_ray(:,centroid(1)))]);
    if ind==1
      mask_ray_temp(centroid(2),:) = 1;
    else
      mask_ray_temp(:,centroid(1)) = 1;
    end
    mask_ray(rotateAround(mask_ray_temp,centroid(2),centroid(1),0)) = 1;
    for i = [13,26,39,51,64,77,90]
    mask_ray(rotateAround(mask_ray_temp,centroid(2),centroid(1),i)) = 1;
    mask_ray(rotateAround(mask_ray_temp,centroid(2),centroid(1),-i)) = 1;
    end
    %DEBUG: imshow(labeloverlay(img_temp,mask_ray))
    
    temp = bwperim(cells_temp);
    temp = imdilate(temp,strel('disk',2,8));
    
    border_in = and(cells_temp,temp);
    border_in(mask_ray) = 0;
    border_out = temp;
    border_out(cells_temp) = 0;
    border_out(mask_ray) = 0;
    CC_in = bwconncomp(border_in,4);
    CC_out = bwconncomp(border_out,4);

    inds = 1:min(CC_in.NumObjects,CC_out.NumObjects);
    
    %DEBUG: figure; imshow(labeloverlay(img_temp,or(border_in,border_out)))

    
    temp = arrayfun(@(x) mean2(img_temp(CC_out.PixelIdxList{x})) - ...
                         mean2(img_temp(CC_in.PixelIdxList{x})),inds);
    border_min = min(temp);
    
    stats = regionprops(cells{1},'Solidity');
    if border_min>0.04 && stats.Solidity>0.98
      imgs{k}{l} = img_temp;
      masks{k}{l} = cells;
    end
 end
end

%% Rearenging and processing for further usage

masks_new = masks(:);

inds = 1:length(masks_new);
masks_log = arrayfun(@(x) ~isempty(masks_new{x}), inds);
masks_new = masks_new(masks_log);

masks_new = cat(1,masks_new{:});
inds = 1:length(masks_new);
masks_log = arrayfun(@(x) ~isempty(masks_new{x}), inds);
masks_new = masks_new(masks_log);

imgs_new = imgs(:);
inds = 1:length(imgs);
imgs_log = arrayfun(@(x) ~isempty(imgs_new{x}), inds);
imgs_new = imgs_new(imgs_log);

imgs_new = cat(1,imgs_new{:});
inds = 1:length(imgs_new);
imgs_log = arrayfun(@(x) ~isempty(imgs_new{x}), inds);
imgs_new = imgs_new(imgs_log);
background = 0.85;
dif = 0.01;
imgs_BB = imgs_new;
for i = 1:length(imgs_new) 
  
  if length(masks_new{i})==1
    temp = masks_new{i}{1};
  else
    temp = or(masks_new{i}{1},masks_new{i}{2});  
  end
  
  mask_dilated = logical(imdilate(temp,ones(10)));
  imgs_BB{i}(~mask_dilated) = 0;
  stats = regionprops(mask_dilated,'PixelList');
  row = [min(stats.PixelList(:,2))-5,max(stats.PixelList(:,2))+5];
  col = [min(stats.PixelList(:,1))-5,max(stats.PixelList(:,1))+5];
  imgs_BB{i} = imgs_BB{i}(row(1):row(2),col(1):col(2));
  imgs_BB{i}(imgs_BB{i}==0) = background + rand(1,sum(imgs_BB{i}==0,'all'))*dif;
  mask_temp = logical(imdilate(temp(row(1):row(2),col(1):col(2)),ones(4)));
  imgs_dilated_temp = imgs_BB{i};
  imgs_dilated_temp(imgs_dilated_temp<background) = background;
  imgs_dilated_temp = imgaussfilt(imgs_dilated_temp,2);
  imgs_dilated_temp(mask_temp) = imgs_BB{i}(mask_temp);
  imgs_BB{i} = imgs_dilated_temp;
  
  for j = 1:length(masks_new{i})
    masks_new{i}{j} =  masks_new{i}{j}(row(1):row(2),col(1):col(2));
  end
   
end

rng('default')
inds = randperm(length(imgs_BB));
masks_new = masks_new(inds);
imgs_BB = imgs_BB(inds);

out = {masks_new,imgs_BB};

end
