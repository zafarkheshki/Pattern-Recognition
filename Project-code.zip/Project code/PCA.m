
function [train,test] = PCA(train,test,num)

X = [train{1}(:,num)',train{2}(:,num)',train{3}(:,num)'];
labels = [ones(size(train{1},1),1);2*ones(size(train{2},1),1);3*ones(size(train{3},1),1)];
Mu = mean(X,2); % find mean
Xp = X-Mu; % shift
cov_mat = cov(Xp'); % get covariance matrix
[v,d] = eig(cov_mat,'vector'); % v - eigenvectorsd - eigenvalues; 
[~,index] = sort(d); % sort according to eigenvalues
train = (v(:,index)*Xp)'; % use all eigenvectors for full reconstruction
train = {train(labels==1,:),train(labels==2,:),train(labels==3,:)};
test = (v*(test(:,num)'-Mu))';

%DEBUG:
% figure
% scatter3(train{1}(:,1),train{1}(:,2),train{1}(:,3))
% hold on
% scatter3(train{2}(:,1),train{2}(:,2),train{2}(:,3))
% scatter3(train{3}(:,1),train{3}(:,2),train{3}(:,3))
% 
% scatter3(test(:,1),test(:,2),test(:,3))
% hold off
end
